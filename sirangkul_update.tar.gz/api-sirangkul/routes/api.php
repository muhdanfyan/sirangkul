<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

use App\Http\Controllers\AuthController;

// Health check endpoint
Route::get('/', function () {
    return response()->json([
        'status' => 'ok',
        'message' => 'SiRangkul API is running',
        'version' => '1.0.0',
        'timestamp' => now()->toDateTimeString()
    ]);
});

Route::get('/health', function () {
    return response()->json([
        'status' => 'healthy',
        'database' => 'connected',
        'timestamp' => now()->toDateTimeString()
    ]);
});

use App\Http\Controllers\NotificationController;
use App\Http\Controllers\ProposalAttachmentController;
use App\Http\Controllers\ApprovalWorkflowController;
use App\Http\Controllers\AuditLogController;
use App\Http\Controllers\FeedbackController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\RkamController;
use App\Http\Controllers\ProposalController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ReportingController;
use App\Http\Controllers\CategoryController;

Route::get('reporting/summary', [ReportingController::class, 'getSummary'])->middleware('auth:sanctum');
Route::get('reporting/monthly-trends', [ReportingController::class, 'getMonthlyTrends'])->middleware('auth:sanctum');
Route::get('reporting/category-breakdown', [ReportingController::class, 'getCategoryBreakdown'])->middleware('auth:sanctum');
Route::get('reporting/export', [ReportingController::class, 'exportReport'])->middleware('auth:sanctum');

Route::apiResource('proposals', ProposalController::class)->middleware('auth:sanctum');

// Proposal action routes
Route::middleware('auth:sanctum')->group(function () {
    Route::post('/proposals/{id}/submit', [ProposalController::class, 'submit']);
    Route::post('/proposals/{id}/verify', [ProposalController::class, 'verify']);
    Route::post('/proposals/{id}/approve', [ProposalController::class, 'approve']);
    Route::post('/proposals/{id}/reject', [ProposalController::class, 'reject']);
    Route::post('/proposals/{id}/final-approve', [ProposalController::class, 'finalApprove']);
    
    // Proposal query routes
    Route::get('/proposals/my-proposals', [ProposalController::class, 'myProposals']);
    Route::get('/proposals/statistics', [ProposalController::class, 'statistics']);
    Route::get('/proposals/kategori/{kategori}', [ProposalController::class, 'getByKategori']);
});

// Payment Management Routes
Route::middleware('auth:sanctum')->group(function () {
    Route::get('/payments', [PaymentController::class, 'index']);
    Route::get('/payments/pending', [PaymentController::class, 'getPendingPayments']);
    Route::get('/payments/{id}', [PaymentController::class, 'show']);
    Route::get('/payments/{id}/download-proof', [PaymentController::class, 'downloadPaymentProof']);
    
    // Payment Actions (Bendahara only - checked in controller)
    Route::post('/payments/{proposalId}/process', [PaymentController::class, 'processPayment']);
    Route::post('/payments/{id}/complete', [PaymentController::class, 'completePayment']);
    Route::post('/payments/{id}/cancel', [PaymentController::class, 'cancelPayment']);
    Route::post('/payments/{id}/reject', [PaymentController::class, 'reject']);
});

Route::apiResource('users', UserController::class)->middleware('auth:sanctum');
Route::apiResource('feedback', FeedbackController::class)->middleware('auth:sanctum');

Route::post('/auth/login', [AuthController::class, 'login'])->middleware('throttle:5,1');
Route::post('/auth/logout', [AuthController::class, 'logout'])->middleware('auth:sanctum');
Route::get('/auth/me', [AuthController::class, 'me'])->middleware('auth:sanctum');

// Debug endpoint for checking user role
Route::middleware('auth:sanctum')->get('/debug/me', function (Request $request) {
    $user = $request->user();
    return response()->json([
        'success' => true,
        'user' => [
            'id' => $user->id,
            'full_name' => $user->full_name,
            'email' => $user->email,
            'role' => $user->role,
        ],
        'role_checks' => [
            'is_verifikator' => $user->isVerifikator(),
            'is_kepala_madrasah' => $user->isKepalaMadrasah(),
            'is_komite' => $user->isKomite(),
            'is_bendahara' => $user->isBendahara(),
            'is_pengusul' => $user->isPengusul(),
            'is_admin' => $user->isAdmin(),
        ],
        'role_lowercase' => strtolower($user->role),
        'token_valid' => true
    ]);
});

// RKAM Routes
Route::middleware('auth:sanctum')->group(function () {
    Route::get('/rkam', [RkamController::class, 'index']);
    Route::get('/rkam/options', [RkamController::class, 'getOptions']);
    Route::post('/rkam', [RkamController::class, 'store']);
    Route::get('/rkam/available/list', [RkamController::class, 'getAvailable']); // Must be before {id} route
    Route::get('/rkam/kategori/{kategori}', [RkamController::class, 'getByKategori']); // Must be before {id} route
    Route::get('/rkam/{id}', [RkamController::class, 'show']);
    Route::put('/rkam/{id}', [RkamController::class, 'update']);
    Route::delete('/rkam/{id}', [RkamController::class, 'destroy']);
    Route::get('/rkam/{id}/proposals', [RkamController::class, 'proposals']);
    
    // Category Management
    Route::apiResource('categories', CategoryController::class);
});

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});