<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class TestLoginCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'test:login';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Test the login functionality';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $this->call('migrate:fresh');

        $user = User::create([
            'id' => 'a1b2c3d4-e5f6-7890-1234-567890abcde0',
            'full_name' => 'Administrator',
            'email' => 'admin@sirangkul.com',
            'password' => Hash::make('password'),
            'role' => 'administrator',
            'status' => 'Active',
        ]);

        $credentials = ['email' => 'admin@sirangkul.com', 'password' => 'password'];

        if (Auth::attempt($credentials)) {
            $this->info('Login successful');
        } else {
            $this->error('Login failed');
        }
    }
}