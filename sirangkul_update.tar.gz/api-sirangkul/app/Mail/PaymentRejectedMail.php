<?php

namespace App\Mail;

use App\Models\Payment;
use App\Models\Proposal;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class PaymentRejectedMail extends Mailable
{
    use Queueable, SerializesModels;

    public $payment;
    public $proposal;

    /**
     * Create a new message instance.
     */
    public function __construct(Payment $payment, Proposal $proposal)
    {
        $this->payment = $payment;
        $this->proposal = $proposal;
    }

    /**
     * Build the message.
     */
    public function build()
    {
        return $this->subject('Pembayaran Ditolak - ' . $this->proposal->title)
                    ->markdown('emails.payments.rejected')
                    ->with([
                        'proposalTitle' => $this->proposal->title,
                        'rejectedBy' => $this->payment->rejectedByUser?->full_name ?? 'Admin',
                        'rejectionReason' => $this->payment->rejection_reason,
                        'improvementSuggestions' => $this->payment->improvement_suggestions,
                        'amount' => number_format($this->payment->amount, 0, ',', '.'),
                        'proposalUrl' => config('app.frontend_url') . '/proposals/' . $this->proposal->id
                    ]);
    }
}
