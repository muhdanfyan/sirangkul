<?php

namespace App\Mail;

use App\Models\Proposal;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ProposalRejectedMail extends Mailable
{
    use Queueable, SerializesModels;

    public $proposal;

    /**
     * Create a new message instance.
     */
    public function __construct(Proposal $proposal)
    {
        $this->proposal = $proposal;
    }

    /**
     * Build the message.
     */
    public function build()
    {
        return $this->subject('Proposal Anda Ditolak - ' . $this->proposal->title)
                    ->markdown('emails.proposals.rejected')
                    ->with([
                        'proposalTitle' => $this->proposal->title,
                        'rejectedBy' => $this->proposal->rejectedByUser?->full_name ?? 'Admin',
                        'rejectedByRole' => $this->getRoleLabel($this->proposal->rejected_by_role),
                        'rejectionReason' => $this->proposal->rejection_reason,
                        'improvementSuggestions' => $this->proposal->improvement_suggestions,
                        'proposalUrl' => config('app.frontend_url') . '/proposals/' . $this->proposal->id
                    ]);
    }

    /**
     * Get role label in Indonesian
     */
    private function getRoleLabel($role)
    {
        $labels = [
            'verifikator' => 'Verifikator',
            'kepala_madrasah' => 'Kepala Madrasah',
            'komite_madrasah' => 'Komite Madrasah',
            'bendahara' => 'Bendahara'
        ];
        return $labels[$role] ?? $role;
    }
}
