<?php

namespace App\Http\Controllers;

use App\Models\Rkam;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class RkamController extends Controller
{
    /**
     * GET /api/rkam
     * List RKAM with pagination and timeframe-based realization
     */
    public function index(Request $request)
    {
        $perPage = $request->input('per_page', 15);
        $startDate = $request->input('start_date');
        $endDate = $request->input('end_date');
        $sortBy = $request->input('sort_by', 'created_at');
        $order = $request->input('order', 'desc');

        // Base query with category relationship
        $query = Rkam::with(['category']);

        // Filter by category_id
        if ($request->has('category_id') && $request->category_id !== 'all') {
            $query->where('category_id', $request->category_id);
        }

        // Filter by old-style kategori string (for backward compatibility)
        if ($request->has('kategori') && $request->kategori !== 'all') {
            $query->where('kategori', $request->kategori);
        }

        // Filter by tahun_anggaran
        if ($request->has('tahun_anggaran')) {
            $query->where('tahun_anggaran', $request->tahun_anggaran);
        }

        // Search by item_name
        if ($request->has('search')) {
            $query->where('item_name', 'like', '%' . $request->search . '%');
        }

        // Subquery for REALIZATION (terpakai) within timeframe
        $query->select('*');
        $query->addSelect([
            'realization' => DB::table('proposals')
                ->selectRaw('COALESCE(SUM(jumlah_pengajuan), 0)')
                ->whereColumn('rkam_id', 'rkams.id')
                ->where('status', 'approved')
                ->when($startDate, fn($q) => $q->where('created_at', '>=', $startDate))
                ->when($endDate, fn($q) => $q->where('created_at', '<=', $endDate))
        ]);

        // Sorting
        $allowedSorts = ['kategori', 'item_name', 'pagu', 'volume', 'satuan', 'unit_price', 'dana_bos', 'dana_komite', 'tahun_anggaran', 'created_at', 'realization'];
        if (in_array($sortBy, $allowedSorts)) {
            if ($sortBy === 'realization') {
                $query->orderBy('realization', $order);
            } else {
                $query->orderBy($sortBy, $order);
            }
        } else {
            $query->orderBy('created_at', 'desc');
        }

        if ($request->has('no_paginate') && $request->no_paginate == 'true') {
            $rkamList = $query->get();
            
            // Transform the collection directly
            $rkamList->transform(function($item) {
                $item->terpakai_filtered = (float) $item->realization;
                $item->sisa_filtered = (float) ($item->pagu - $item->terpakai_filtered);
                $item->persentase_filtered = $item->pagu > 0 ? ($item->terpakai_filtered / $item->pagu) * 100 : 0;
                return $item;
            });

            return response()->json([
                'success' => true,
                'message' => 'Full RKAM list retrieved successfully',
                'data' => $rkamList
            ], 200);
        }

        $rkamList = $query->paginate($perPage);

        // Transform to include computed fields based on the filtered realization
        $rkamList->getCollection()->transform(function($item) {
            $item->terpakai_filtered = (float) $item->realization;
            $item->sisa_filtered = (float) ($item->pagu - $item->terpakai_filtered);
            $item->persentase_filtered = $item->pagu > 0 ? ($item->terpakai_filtered / $item->pagu) * 100 : 0;
            return $item;
        });

        return response()->json([
            'success' => true,
            'message' => 'RKAM list retrieved successfully',
            'data' => $rkamList
        ], 200);
    }

    /**
     * GET /api/rkam/options
     * Get unique options for dropdowns (Categories and Units)
     */
    public function getOptions()
    {
        $categories = Category::orderBy('name', 'asc')->get();
        $units = Rkam::whereNotNull('satuan')->distinct()->pluck('satuan');

        return response()->json([
            'success' => true,
            'data' => [
                'categories' => $categories,
                'units' => $units
            ]
        ]);
    }

    /**
     * GET /api/rkam/{id}
     */
    public function show($id)
    {
        $rkam = Rkam::with(['category', 'proposals.user'])->find($id);

        if (!$rkam) {
            return response()->json(['success' => false, 'message' => 'RKAM not found'], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $rkam
        ], 200);
    }

    /**
     * POST /api/rkam
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'category_id' => 'required|exists:categories,id',
            'item_name' => 'required|string|max:255',
            'volume' => 'required|numeric|min:0',
            'satuan' => 'required|string|max:50',
            'unit_price' => 'required|numeric|min:0',
            'dana_bos' => 'nullable|numeric|min:0',
            'dana_komite' => 'nullable|numeric|min:0',
            'tahun_anggaran' => 'required|integer|min:2020|max:2100',
            'deskripsi' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['success' => false, 'errors' => $validator->errors()], 422);
        }

        $data = $validator->validated();
        
        // Auto-calculate pagu if not provided
        $data['pagu'] = $data['volume'] * $data['unit_price'];
        
        // Sync old-style kategori string for compatibility
        $category = Category::find($data['category_id']);
        $data['kategori'] = $category->name;

        $rkam = Rkam::create($data);

        return response()->json([
            'success' => true,
            'message' => 'RKAM berhasil ditambahkan',
            'data' => $rkam
        ], 201);
    }

    /**
     * PUT /api/rkam/{id}
     */
    public function update(Request $request, $id)
    {
        $rkam = Rkam::find($id);

        if (!$rkam) {
            return response()->json(['success' => false, 'message' => 'RKAM not found'], 404);
        }

        $validator = Validator::make($request->all(), [
            'category_id' => 'sometimes|required|exists:categories,id',
            'item_name' => 'sometimes|required|string|max:255',
            'volume' => 'sometimes|required|numeric|min:0',
            'satuan' => 'sometimes|required|string|max:50',
            'unit_price' => 'sometimes|required|numeric|min:0',
            'dana_bos' => 'nullable|numeric|min:0',
            'dana_komite' => 'nullable|numeric|min:0',
            'tahun_anggaran' => 'sometimes|required|integer|min:2020|max:2100',
            'deskripsi' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['success' => false, 'errors' => $validator->errors()], 422);
        }

        $data = $validator->validated();
        
        // Recalculate pagu if volume or price changes
        if (isset($data['volume']) || isset($data['unit_price'])) {
            $volume = $data['volume'] ?? $rkam->volume;
            $price = $data['unit_price'] ?? $rkam->unit_price;
            $data['pagu'] = $volume * $price;
        }

        // Sync old-style kategori string if category_id changes
        if (isset($data['category_id'])) {
            $category = Category::find($data['category_id']);
            $data['kategori'] = $category->name;
        }

        $rkam->update($data);

        return response()->json([
            'success' => true,
            'message' => 'RKAM berhasil diperbarui',
            'data' => $rkam->fresh(['category'])
        ], 200);
    }

    /**
     * DELETE /api/rkam/{id}
     */
    public function destroy($id)
    {
        $rkam = Rkam::find($id);

        if (!$rkam) {
            return response()->json(['success' => false, 'message' => 'RKAM not found'], 404);
        }

        if ($rkam->proposals()->count() > 0) {
            return response()->json([
                'success' => false,
                'message' => 'Tidak dapat menghapus RKAM yang sudah memiliki proposal terkait.'
            ], 400);
        }

        $rkam->delete();

        return response()->json([
            'success' => true,
            'message' => 'RKAM berhasil dihapus'
        ], 200);
    }
}
