<?php

namespace App\Http\Controllers;

use App\Models\Feedback;
use Illuminate\Http\Request;

class FeedbackController extends Controller
{
    public function index(Request $request)
    {
        $feedback = Feedback::query();

        if ($request->has('proposal_id')) {
            $feedback->where('proposal_id', $request->input('proposal_id'));
        }

        return response()->json($feedback->get());
    }

    public function store(Request $request)
    {
        $feedback = Feedback::create([
            'proposal_id' => $request->input('proposal_id'),
            'message' => $request->input('message'),
            'user_id' => $request->user()->id,
        ]);

        return response()->json($feedback);
    }
}
