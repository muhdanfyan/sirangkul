<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Models\Proposal;
use App\Models\Rkam;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class PaymentController extends Controller
{
    /**
     * GET /api/payments
     * List all payments
     */
    public function index(Request $request)
    {
        $query = Payment::with([
            'proposal.user:id,full_name,email',
            'proposal.rkam:id,kategori,item_name',
            'processedByUser:id,full_name'
        ]);
        
        // Filter by status
        if ($request->has('status')) {
            $query->where('status', $request->status);
        }
        
        // Filter by payment method
        if ($request->has('payment_method')) {
            $query->where('payment_method', $request->payment_method);
        }
        
        // Order by created_at desc
        $payments = $query->latest()->get();
        
        return response()->json([
            'success' => true,
            'message' => 'Payments retrieved successfully',
            'data' => $payments
        ]);
    }
    
    /**
     * GET /api/payments/pending
     * Get proposals yang perlu dibayar (status = final_approved)
     * Hanya menampilkan proposal yang BELUM punya payment record
     */
    public function getPendingPayments()
    {
        try {
            // Query proposal dengan status final_approved
            // Yang BELUM punya payment record
            $proposals = Proposal::where('status', Proposal::STATUS_FINAL_APPROVED)
                ->whereDoesntHave('payment') // Proposal yang belum punya payment
                ->with([
                    'user:id,full_name,email,role',
                    'rkam:id,kategori,item_name,pagu,tahun_anggaran',
                    'finalApprover:id,full_name,role'
                ])
                ->orderBy('final_approved_at', 'desc')
                ->get();

            return response()->json([
                'success' => true,
                'message' => 'Pending payments retrieved successfully',
                'data' => $proposals,
                'count' => $proposals->count()
            ]);
            
        } catch (\Exception $e) {
            Log::error('Error fetching pending payments: ' . $e->getMessage());
            
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch pending payments: ' . $e->getMessage(),
                'data' => [],
                'count' => 0
            ], 500);
        }
    }
    
    /**
     * GET /api/payments/{id}
     * Get payment detail
     */
    public function show($id)
    {
        $payment = Payment::with([
            'proposal.user',
            'proposal.rkam',
            'processedByUser'
        ])->findOrFail($id);
        
        return response()->json([
            'success' => true,
            'message' => 'Payment retrieved successfully',
            'data' => $payment
        ]);
    }
    
    /**
     * POST /api/payments/{proposalId}/process
     * Mulai proses pembayaran (final_approved → payment_processing)
     */
    public function processPayment(Request $request, $proposalId)
    {
        $user = $request->user();
        
        // Authorization: Hanya Bendahara
        if (!$user->isBendahara()) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized: Only Bendahara can process payments',
                'debug' => [
                    'your_role' => $user->role,
                    'required_role' => 'bendahara'
                ]
            ], 403);
        }
        
        $proposal = Proposal::findOrFail($proposalId);
        
        // Validasi status
        if ($proposal->status !== Proposal::STATUS_FINAL_APPROVED) {
            return response()->json([
                'success' => false,
                'message' => 'Proposal not in final_approved status',
                'debug' => [
                    'current_status' => $proposal->status,
                    'required_status' => Proposal::STATUS_FINAL_APPROVED
                ]
            ], 400);
        }
        
        // Validasi input
        $validator = Validator::make($request->all(), [
            'recipient_name' => 'required|string|max:255',
            'recipient_account' => 'required|string|max:100',
            'bank_name' => 'nullable|string|max:100',
            'payment_method' => 'required|in:transfer,cash,check',
            'payment_reference' => 'nullable|string|max:100',
            'notes' => 'nullable|string',
        ]);
        
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }
        
        DB::beginTransaction();
        try {
            // Create payment record
            $payment = Payment::create([
                'proposal_id' => $proposal->id,
                'amount' => $proposal->jumlah_pengajuan,
                'recipient_name' => $request->recipient_name,
                'recipient_account' => $request->recipient_account,
                'bank_name' => $request->bank_name,
                'payment_method' => $request->payment_method,
                'payment_reference' => $request->payment_reference,
                'notes' => $request->notes,
                'status' => Payment::STATUS_PROCESSING,
                'processed_at' => now(),
                'processed_by' => $user->id
            ]);
            
            // Update proposal status
            $proposal->update([
                'status' => Proposal::STATUS_PAYMENT_PROCESSING
            ]);
            
            DB::commit();
            
            return response()->json([
                'success' => true,
                'message' => 'Payment processing started successfully',
                'data' => [
                    'payment_id' => $payment->id,
                    'proposal_id' => $proposal->id,
                    'status' => $payment->status,
                    'amount' => $payment->amount,
                    'processed_at' => $payment->processed_at
                ]
            ]);
            
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Failed to process payment: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * POST /api/payments/{id}/complete
     * Selesaikan pembayaran (payment_processing → completed)
     */
    public function completePayment(Request $request, $id)
    {
        $user = $request->user();
        
        // Authorization: Hanya Bendahara
        if (!$user->isBendahara()) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized: Only Bendahara can complete payments',
                'debug' => [
                    'your_role' => $user->role,
                    'required_role' => 'bendahara'
                ]
            ], 403);
        }
        
        $payment = Payment::with('proposal.rkam')->findOrFail($id);
        
        // Validasi status
        if ($payment->status !== Payment::STATUS_PROCESSING) {
            return response()->json([
                'success' => false,
                'message' => 'Payment not in processing status',
                'debug' => [
                    'current_status' => $payment->status,
                    'required_status' => Payment::STATUS_PROCESSING
                ]
            ], 400);
        }
        
        // Validasi input
        $validator = Validator::make($request->all(), [
            'payment_proof_url' => 'nullable|url|max:2048',
            'payment_proof_file' => 'nullable|file|mimes:jpg,jpeg,png,pdf|max:10240',
            'admin_notes' => 'nullable|string|max:1000',
        ]);
        
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }
        
        // At least one proof is required
        if (empty($request->payment_proof_url) && !$request->hasFile('payment_proof_file')) {
            return response()->json([
                'success' => false,
                'message' => 'Payment proof (URL or file) is required'
            ], 422);
        }
        
        DB::beginTransaction();
        try {
            // Handle file upload
            $paymentProofFile = null;
            if ($request->hasFile('payment_proof_file')) {
                $file = $request->file('payment_proof_file');
                $filename = 'payment_' . $payment->id . '_' . time() . '.' . $file->extension();
                $path = $file->storeAs('payment_proofs', $filename, 'public');
                $paymentProofFile = $path;
            }
            
            // Update payment status
            $payment->update([
                'status' => Payment::STATUS_COMPLETED,
                'payment_proof_url' => $request->payment_proof_url,
                'payment_proof_file' => $paymentProofFile,
                'admin_notes' => $request->admin_notes,
                'completed_at' => now()
            ]);
            
            // Update proposal status
            $proposal = $payment->proposal;
            $proposal->update([
                'status' => Proposal::STATUS_COMPLETED,
                'completed_at' => now()
            ]);
            
            // Update RKAM terpakai & sisa
            $rkam = $proposal->rkam;
            $oldTerpakai = (float)$rkam->terpakai;
            $newTerpakai = $oldTerpakai + (float)$payment->amount;
            $newSisa = (float)$rkam->pagu - $newTerpakai;
            
            $rkam->update([
                'terpakai' => $newTerpakai,
                'sisa' => $newSisa
            ]);
            
            DB::commit();
            
            return response()->json([
                'success' => true,
                'message' => 'Payment completed successfully. RKAM updated.',
                'data' => [
                    'payment_id' => $payment->id,
                    'payment_status' => $payment->status,
                    'proposal_id' => $proposal->id,
                    'proposal_status' => $proposal->status,
                    'rkam_update' => [
                        'rkam_id' => $rkam->id,
                        'old_terpakai' => $oldTerpakai,
                        'new_terpakai' => $newTerpakai,
                        'new_sisa' => $newSisa
                    ]
                ]
            ]);
            
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Failed to complete payment: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * POST /api/payments/{id}/cancel
     * Batalkan pembayaran
     */
    public function cancelPayment(Request $request, $id)
    {
        $user = $request->user();
        
        // Authorization: Hanya Bendahara
        if (!$user->isBendahara()) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized: Only Bendahara can cancel payments',
                'debug' => [
                    'your_role' => $user->role,
                    'required_role' => 'bendahara'
                ]
            ], 403);
        }
        
        $payment = Payment::with('proposal')->findOrFail($id);
        
        // Validasi status
        if ($payment->status === Payment::STATUS_COMPLETED) {
            return response()->json([
                'success' => false,
                'message' => 'Cannot cancel completed payment'
            ], 400);
        }
        
        DB::beginTransaction();
        try {
            // Update payment status
            $payment->update([
                'status' => Payment::STATUS_FAILED,
                'admin_notes' => $request->reason ?? 'Payment cancelled'
            ]);
            
            // Kembalikan proposal ke final_approved
            $proposal = $payment->proposal;
            $proposal->update([
                'status' => Proposal::STATUS_FINAL_APPROVED
            ]);
            
            DB::commit();
            
            return response()->json([
                'success' => true,
                'message' => 'Payment cancelled. Proposal returned to final_approved status.',
                'data' => [
                    'payment_id' => $payment->id,
                    'payment_status' => $payment->status,
                    'proposal_id' => $proposal->id,
                    'proposal_status' => $proposal->status
                ]
            ]);
            
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Failed to cancel payment: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * GET /api/payments/{id}/download-proof
     * Download payment proof file
     */
    public function downloadPaymentProof(Request $request, $id)
    {
        $payment = Payment::with('proposal')->findOrFail($id);
        $user = $request->user();
        
        // Authorization: Only proposal owner, admin, or approvers can download
        if ($user->role === 'pengusul' && $payment->proposal->user_id !== $user->id) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized'
            ], 403);
        }
        
        if (!$payment->payment_proof_file) {
            return response()->json([
                'success' => false,
                'message' => 'No payment proof file available'
            ], 404);
        }
        
        $filePath = storage_path('app/public/' . $payment->payment_proof_file);
        
        if (!file_exists($filePath)) {
            return response()->json([
                'success' => false,
                'message' => 'Payment proof file not found'
            ], 404);
        }
        
        return response()->download($filePath);
    }

    /**
     * POST /api/payments/{id}/reject
     * Reject a payment with improvement suggestions
     */
    public function reject(Request $request, $id)
    {
        // Validation
        $validator = Validator::make($request->all(), [
            'rejection_reason' => 'required|string|min:10|max:1000',
            'improvement_suggestions' => 'required|string|min:20|max:2000'
        ], [
            'rejection_reason.required' => 'Alasan penolakan wajib diisi',
            'rejection_reason.min' => 'Alasan penolakan minimal 10 karakter',
            'rejection_reason.max' => 'Alasan penolakan maksimal 1000 karakter',
            'improvement_suggestions.required' => 'Saran perbaikan wajib diisi',
            'improvement_suggestions.min' => 'Saran perbaikan minimal 20 karakter',
            'improvement_suggestions.max' => 'Saran perbaikan maksimal 2000 karakter',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $payment = Payment::with('proposal')->findOrFail($id);
        $user = $request->user();

        // Authorization: Only bendahara can reject payments
        if (!$user->isBendahara()) {
            return response()->json([
                'success' => false,
                'message' => 'Hanya bendahara yang dapat menolak pembayaran'
            ], 403);
        }

        // Can only reject pending or processing payments
        if (!in_array($payment->status, [Payment::STATUS_PENDING, Payment::STATUS_PROCESSING])) {
            return response()->json([
                'success' => false,
                'message' => 'Hanya pembayaran dengan status pending atau processing yang dapat ditolak'
            ], 400);
        }

        DB::beginTransaction();
        try {
            // Update payment status
            $payment->update([
                'status' => Payment::STATUS_REJECTED,
                'rejected_at' => now(),
                'rejected_by' => $user->id,
                'rejected_by_role' => $user->role,
                'rejection_reason' => $request->rejection_reason,
                'improvement_suggestions' => $request->improvement_suggestions,
            ]);

            // Update proposal - return to final_approved so it can be reprocessed
            $proposal = $payment->proposal;
            if ($proposal) {
                $proposal->update([
                    'status' => Proposal::STATUS_FINAL_APPROVED,
                    // Keep the approval timestamps - don't reset them
                ]);
            }

            // TODO: Log audit activity
            // TODO: Send notification to proposer

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Pembayaran berhasil ditolak. Proposal dikembalikan untuk perbaikan data.',
                'data' => [
                    'payment_id' => $payment->id,
                    'payment_status' => $payment->status,
                    'proposal_id' => $proposal?->id,
                    'proposal_status' => $proposal?->status,
                    'rejection_reason' => $payment->rejection_reason,
                    'improvement_suggestions' => $payment->improvement_suggestions
                ]
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();
            
            return response()->json([
                'success' => false,
                'message' => 'Gagal menolak pembayaran: ' . $e->getMessage()
            ], 500);
        }
    }
}
