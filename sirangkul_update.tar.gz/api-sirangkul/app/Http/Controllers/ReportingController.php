<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ReportingController extends Controller
{
    public function getSummary(Request $request)
    {
        $totalBudget = \App\Models\Rkam::sum('pagu');
        $usedBudget = \App\Models\Proposal::whereIn('status', [
            \App\Models\Proposal::STATUS_APPROVED, 
            \App\Models\Proposal::STATUS_FINAL_APPROVED,
            \App\Models\Proposal::STATUS_COMPLETED
        ])->sum('jumlah_pengajuan');
        
        $data = [
            "totalProposals" => \App\Models\Proposal::count(),
            "approvedProposals" => \App\Models\Proposal::whereIn('status', [
                \App\Models\Proposal::STATUS_APPROVED, 
                \App\Models\Proposal::STATUS_FINAL_APPROVED, 
                \App\Models\Proposal::STATUS_COMPLETED
            ])->count(),
            "rejectedProposals" => \App\Models\Proposal::where('status', \App\Models\Proposal::STATUS_REJECTED)->count(),
            "pendingProposals" => \App\Models\Proposal::whereIn('status', [
                \App\Models\Proposal::STATUS_SUBMITTED, 
                \App\Models\Proposal::STATUS_VERIFIED,
                \App\Models\Proposal::STATUS_PAYMENT_PROCESSING
            ])->count(),
            "totalBudget" => (float) $totalBudget,
            "usedBudget" => (float) $usedBudget,
            "remainingBudget" => (float) ($totalBudget - $usedBudget)
        ];

        return response()->json($data);
    }

    public function getMonthlyTrends(Request $request)
    {
        $trends = \App\Models\Proposal::selectRaw('DATE_FORMAT(created_at, "%b") as month, COUNT(*) as proposals, SUM(jumlah_pengajuan) as budget')
            ->groupBy('month')
            ->orderBy('created_at')
            ->get();

        return response()->json($trends);
    }

    public function getCategoryBreakdown(Request $request)
    {
        $breakdown = \App\Models\Proposal::join('rkams', 'proposals.rkam_id', '=', 'rkams.id')
            ->selectRaw('rkams.kategori as name, COUNT(*) as count, SUM(proposals.jumlah_pengajuan) as budget')
            ->groupBy('rkams.kategori')
            ->get();

        $totalCount = $breakdown->sum('count');
        $breakdown->transform(function ($item) use ($totalCount) {
            $item->percentage = $totalCount > 0 ? round(($item->count / $totalCount) * 100) : 0;
            return $item;
        });

        return response()->json($breakdown);
    }

    public function exportReport(Request $request)
    {
        $format = $request->query('format', 'csv');
        $proposals = \App\Models\Proposal::with(['user', 'rkam'])->get();

        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="laporan_proposal_' . date('Ymd_His') . '.csv"',
            'Access-Control-Expose-Headers' => 'Content-Disposition',
        ];

        $callback = function() use ($proposals) {
            $file = fopen('php://output', 'w');
            fputcsv($file, ['ID', 'Judul Proposal', 'Nama Pengusul', 'Kategori RKAM', 'Jumlah Pengajuan (Rp)', 'Status', 'Tanggal Dibuat']);

            foreach ($proposals as $p) {
                fputcsv($file, [
                    $p->id,
                    $p->title,
                    $p->user ? $p->user->full_name : '-',
                    $p->rkam ? $p->rkam->kategori : '-',
                    $p->jumlah_pengajuan,
                    $p->status,
                    $p->created_at ? $p->created_at->format('Y-m-d H:i') : '-'
                ]);
            }
            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }
}