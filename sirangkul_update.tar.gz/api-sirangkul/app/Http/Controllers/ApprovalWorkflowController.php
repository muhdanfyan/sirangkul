<?php

namespace App\Http\Controllers;

use App\Models\ApprovalWorkflow;
use App\Models\Proposal;
use Illuminate\Http\Request;

class ApprovalWorkflowController extends Controller
{
    public function index(Proposal $proposal)
    {
        return response()->json($proposal->approvals);
    }

    public function store(Request $request, Proposal $proposal)
    {
        $approval = $proposal->approvals()->create([
            'approver_id' => $request->user()->id,
            'status' => $request->input('status'),
            'notes' => $request->input('notes'),
        ]);

        return response()->json($approval);
    }
}
