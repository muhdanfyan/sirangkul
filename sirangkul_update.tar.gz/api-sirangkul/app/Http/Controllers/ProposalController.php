<?php

namespace App\Http\Controllers;

use App\Models\Proposal;
use App\Models\Rkam;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;

class ProposalController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        
        $proposals = Proposal::with([
            'user:id,full_name,email,role',
            'rkam:id,kategori,item_name,pagu,tahun_anggaran,deskripsi',
            'verifier:id,full_name,role',
            'approver:id,full_name,role',
            'rejectedByUser:id,full_name,role',
            'finalApprover:id,full_name,role'
        ]);

        // Authorization: Pengusul hanya bisa melihat proposal miliknya sendiri
        if ($user && strtolower(trim($user->role)) === 'pengusul') {
            $proposals->where('user_id', $user->id);
        }

        if ($request->has('status')) {
            $proposals->where('status', $request->input('status'));
        }

        if ($request->has('rkam_id')) {
            $proposals->where('rkam_id', $request->input('rkam_id'));
        }

        return response()->json([
            'success' => true,
            'message' => 'Proposals retrieved successfully',
            'data' => $proposals->latest()->get()
        ]);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'rkam_id' => 'required|exists:rkam,id',
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'jumlah_pengajuan' => 'required|numeric|min:0',
            'kategori' => 'nullable|in:Kurikulum,Kantor,Sarana Prasarana,Humas,Kesiswaan,Komite',
            'urgency' => 'nullable|in:Rendah,Normal,Tinggi,Mendesak',
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date|after_or_equal:start_date',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        // Validasi: Jumlah pengajuan tidak boleh melebihi sisa RKAM
        $rkam = Rkam::findOrFail($request->rkam_id);
        
        if ($request->jumlah_pengajuan > $rkam->sisa) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => [
                    'jumlah_pengajuan' => [
                        "Jumlah pengajuan (Rp " . number_format($request->jumlah_pengajuan, 0, ',', '.') . 
                        ") melebihi sisa anggaran RKAM (Rp " . number_format($rkam->sisa, 0, ',', '.') . ")"
                    ]
                ]
            ], 422);
        }

        // Cek apakah butuh persetujuan komite (> 50 juta)
        $requiresCommittee = $request->jumlah_pengajuan > 50000000;

        $proposal = Proposal::create([
            'rkam_id' => $request->rkam_id,
            'title' => $request->title,
            'description' => $request->description,
            'jumlah_pengajuan' => $request->jumlah_pengajuan,
            'kategori' => $request->kategori ?? $rkam->kategori, // Use RKAM kategori if not provided
            'urgency' => $request->urgency ?? 'Normal',
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
            'user_id' => $request->user()->id,
            'status' => 'draft',
            'requires_committee_approval' => $requiresCommittee,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Proposal created successfully',
            'data' => $proposal->load('rkam')
        ], 201);
    }

    public function show(Request $request, Proposal $proposal)
    {
        try {
            $user = $request->user();
            
            // Authorization: User can only see their own proposals (unless they're approver)
            if ($user && $user->role === 'pengusul' && $proposal->user_id !== $user->id) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized'
                ], 403);
            }
            
            // Load relations
            $proposal->load([
                'user:id,full_name,email,role',
                'rkam:id,kategori,item_name,pagu,tahun_anggaran,deskripsi',
                'verifier:id,full_name,role',
                'approver:id,full_name,role',
                'finalApprover:id,full_name,role',
                'attachments',
                'payment' => function($query) {
                    $query->select([
                        'id', 'proposal_id', 'amount', 'recipient_name', 
                        'recipient_account', 'bank_name', 'payment_method', 
                        'payment_reference', 'payment_proof_url', 'payment_proof_file',
                        'status', 'completed_at', 'processed_at', 'processed_by',
                        'notes', 'admin_notes', 'rejection_reason', 'improvement_suggestions',
                        'rejected_at', 'rejected_by', 'rejected_by_role'
                    ]);
                },
                'payment.processedByUser:id,full_name,role',
                'payment.rejectedByUser:id,full_name,role'
            ]);
            
            // Load rejectedByUser only if rejected_by exists to avoid null relation errors
            if ($proposal->rejected_by) {
                $proposal->load('rejectedByUser:id,full_name,role,email');
            }
            
            return response()->json([
                'success' => true,
                'message' => 'Proposal retrieved successfully',
                'data' => $proposal
            ]);
        } catch (\Exception $e) {
            Log::error('Error fetching proposal: ' . $e->getMessage(), [
                'proposal_id' => $proposal->id ?? null,
                'user_id' => $request->user()->id ?? null,
                'trace' => $e->getTraceAsString()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve proposal',
                'error' => config('app.debug') ? $e->getMessage() : 'Internal server error'
            ], 500);
        }
    }

    public function update(Request $request, Proposal $proposal)
    {
        // Authorization: Only proposal owner can update
        if ($proposal->user_id !== $request->user()->id) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized: You can only update your own proposals'
            ], 403);
        }

        // Only allow edit if status is draft or rejected
        if (!in_array($proposal->status, [Proposal::STATUS_DRAFT, Proposal::STATUS_REJECTED])) {
            return response()->json([
                'success' => false,
                'message' => 'Proposal can only be edited if status is draft or rejected'
            ], 422);
        }

        $validator = Validator::make($request->all(), [
            'rkam_id' => 'sometimes|required|exists:rkam,id',
            'title' => 'sometimes|required|string|max:255',
            'description' => 'nullable|string',
            'jumlah_pengajuan' => 'sometimes|required|numeric|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        // Jika ada perubahan jumlah_pengajuan atau rkam_id, validasi budget
        if ($request->has('jumlah_pengajuan') || $request->has('rkam_id')) {
            $rkamId = $request->has('rkam_id') ? $request->rkam_id : $proposal->rkam_id;
            $jumlahPengajuan = $request->has('jumlah_pengajuan') ? $request->jumlah_pengajuan : $proposal->jumlah_pengajuan;
            
            $rkam = Rkam::findOrFail($rkamId);
            
            // Hitung sisa budget (tambahkan kembali jumlah proposal ini jika sudah approved)
            $sisaBudget = $rkam->sisa;
            if ($proposal->status === 'approved') {
                $sisaBudget += $proposal->jumlah_pengajuan;
            }
            
            if ($jumlahPengajuan > $sisaBudget) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => [
                        'jumlah_pengajuan' => [
                            "Jumlah pengajuan (Rp " . number_format($jumlahPengajuan, 0, ',', '.') . 
                            ") melebihi sisa anggaran RKAM (Rp " . number_format($sisaBudget, 0, ',', '.') . ")"
                        ]
                    ]
                ], 422);
            }
        }

        // Update proposal fields but keep status unchanged
        // Status will only change when user clicks "Ajukan Ulang" (submit endpoint)
        $proposal->update($request->only(['rkam_id', 'title', 'description', 'jumlah_pengajuan']));

        // Update requires_committee_approval flag if jumlah_pengajuan changed
        if ($request->has('jumlah_pengajuan')) {
            $proposal->requires_committee_approval = $request->jumlah_pengajuan > 50000000;
            $proposal->save();
        }

        return response()->json([
            'success' => true,
            'message' => 'Proposal updated successfully',
            'data' => $proposal->fresh()->load('rkam')
        ]);
    }

    public function destroy(Proposal $proposal)
    {
        $proposal->delete();

        return response()->json([
            'success' => true,
            'message' => 'Proposal deleted successfully'
        ]);
    }

    /**
     * Submit proposal for verification
     */
    public function submit(Request $request, $id)
    {
        $proposal = Proposal::findOrFail($id);

        // Authorization: Only proposal owner can submit
        if ($proposal->user_id !== $request->user()->id) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized: You can only submit your own proposals'
            ], 403);
        }

        // Allow submit if status is draft OR rejected
        if (!in_array($proposal->status, [Proposal::STATUS_DRAFT, Proposal::STATUS_REJECTED])) {
            return response()->json([
                'success' => false,
                'message' => "Proposal can only be submitted if status is draft or rejected"
            ], 422);
        }

        // Store original status for logging and response message
        $originalStatus = $proposal->status;

        // If resubmitting rejected proposal, reset all approval workflow
        if ($proposal->status === Proposal::STATUS_REJECTED) {
            $proposal->verified_at = null;
            $proposal->verified_by = null;
            $proposal->approved_at = null;
            $proposal->approved_by = null;
            $proposal->final_approved_at = null;
            $proposal->final_approved_by = null;
            $proposal->rejected_at = null;
            $proposal->rejected_by = null;
            $proposal->rejection_reason = null;
            $proposal->improvement_suggestions = null;
            $proposal->rejected_by_role = null;
            
            // Track resubmission (if columns exist)
            if (Schema::hasColumn('proposals', 'resubmission_count')) {
                $proposal->resubmission_count = ($proposal->resubmission_count ?? 0) + 1;
            }
            if (Schema::hasColumn('proposals', 'last_resubmitted_at')) {
                $proposal->last_resubmitted_at = now();
            }

            // Log resubmission activity
            Log::info('Proposal resubmitted', [
                'proposal_id' => $proposal->id,
                'user_id' => $request->user()->id,
                'previous_status' => $originalStatus,
                'new_status' => Proposal::STATUS_SUBMITTED
            ]);
        }

        // Set new status and submission timestamp
        $proposal->status = Proposal::STATUS_SUBMITTED;
        $proposal->submitted_at = now();
        $proposal->save();

        return response()->json([
            'success' => true,
            'message' => $originalStatus === Proposal::STATUS_REJECTED 
                ? 'Proposal berhasil diajukan ulang' 
                : 'Proposal submitted successfully',
            'data' => $proposal->fresh()->load([
                'user:id,full_name,email,role',
                'rkam:id,kategori,item_name,pagu,tahun_anggaran'
            ])
        ]);
    }

    /**
     * Verify proposal (Verifikator role)
     */
    public function verify(Request $request, $id)
    {
        $proposal = Proposal::findOrFail($id);
        $user = $request->user();

        // Authorization: Only Verifikator can verify
        if (!$user->isVerifikator()) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized: Only Verifikator can verify proposals',
                'debug' => [
                    'your_role' => $user->role,
                    'required_role' => 'verifikator'
                ]
            ], 403);
        }

        // Status validation
        if ($proposal->status !== Proposal::STATUS_SUBMITTED) {
            return response()->json([
                'success' => false,
                'message' => "Cannot verify: Proposal status is '{$proposal->status}'"
            ], 422);
        }

        $proposal->update([
            'status' => Proposal::STATUS_VERIFIED,
            'verified_at' => now(),
            'verified_by' => $user->id,
        ]);

        // TODO: Create approval workflow record

        return response()->json([
            'success' => true,
            'message' => 'Proposal verified successfully',
            'data' => $proposal->fresh()->load([
                'user:id,full_name,email,role',
                'rkam:id,kategori,item_name,pagu,tahun_anggaran',
                'verifier:id,full_name,role'
            ])
        ]);
    }

    /**
     * Approve proposal (Kepala Madrasah role)
     * Auto final approve if budget <= 50M
     */
    public function approve(Request $request, $id)
    {
        $proposal = Proposal::findOrFail($id);
        $user = $request->user();

        // Authorization check based on current status
        if ($proposal->status === Proposal::STATUS_VERIFIED) {
            // Only Kepala Madrasah can do first approval
            if (!$user->isKepalaMadrasah()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized: Only Kepala Madrasah can approve proposals',
                    'debug' => [
                        'your_role' => $user->role,
                        'required_role' => 'kepala_madrasah'
                    ]
                ], 403);
            }
        } elseif ($proposal->status === Proposal::STATUS_APPROVED) {
            // Only Komite Madrasah can do final approval for high-value proposals
            if (!$user->isKomite()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized: Only Komite Madrasah can give final approval',
                    'debug' => [
                        'your_role' => $user->role,
                        'required_role' => 'komite'
                    ]
                ], 403);
            }
        } else {
            return response()->json([
                'success' => false,
                'message' => "Cannot approve: Invalid proposal status '{$proposal->status}'"
            ], 422);
        }

        // Budget validation (double-check)
        $rkam = $proposal->rkam;
        if ($proposal->jumlah_pengajuan > $rkam->sisa) {
            return response()->json([
                'success' => false,
                'message' => 'Cannot approve: Proposal exceeds available budget'
            ], 422);
        }

        try {
            DB::beginTransaction();

            $nextApprover = null;
            $nextStep = null;

            if ($proposal->status === Proposal::STATUS_VERIFIED) {
                // First approval by Kepala Madrasah
                $proposal->approved_at = now();
                $proposal->approved_by = $user->id;
                
                // ✅ AUTO FINAL APPROVE if not requires committee
                if (!$proposal->requires_committee_approval) {
                    // Auto transition to final_approved
                    $proposal->status = Proposal::STATUS_FINAL_APPROVED;
                    $proposal->final_approved_at = now();
                    $proposal->final_approved_by = $user->id;
                    
                    $nextStep = 'Payment processing';
                    $nextApprover = 'Bendahara';
                    
                } else {
                    // Requires committee approval
                    $proposal->status = Proposal::STATUS_APPROVED;
                    $nextStep = 'Committee approval';
                    $nextApprover = 'Komite Madrasah';
                }
                
            } elseif ($proposal->status === Proposal::STATUS_APPROVED) {
                // Final approval by Komite Madrasah
                $proposal->status = Proposal::STATUS_FINAL_APPROVED;
                $proposal->final_approved_at = now();
                $proposal->final_approved_by = $user->id;
                
                $nextStep = 'Payment processing';
                $nextApprover = 'Bendahara';
            }

            $proposal->save();

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Proposal approved successfully',
                'data' => [
                    'proposal' => $proposal->fresh()->load([
                        'user:id,full_name,email,role',
                        'rkam:id,kategori,item_name,pagu,tahun_anggaran',
                        'verifier:id,full_name,role',
                        'approver:id,full_name,role',
                        'finalApprover:id,full_name,role'
                    ]),
                    'next_approver' => $nextApprover,
                    'next_step' => $nextStep
                ]
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error approving proposal: ' . $e->getMessage());
            
            return response()->json([
                'success' => false,
                'message' => 'Failed to approve proposal: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Reject proposal with improvement suggestions
     */
    public function reject(Request $request, $id)
    {
        try {
            $proposal = Proposal::findOrFail($id);
            $user = $request->user();

            $validator = Validator::make($request->all(), [
                'rejection_reason' => 'required|string|min:10|max:1000',
                'improvement_suggestions' => 'required|string|min:20|max:2000'
            ], [
                'rejection_reason.required' => 'Alasan penolakan wajib diisi',
                'rejection_reason.min' => 'Alasan penolakan minimal 10 karakter',
                'rejection_reason.max' => 'Alasan penolakan maksimal 1000 karakter',
                'improvement_suggestions.required' => 'Saran perbaikan wajib diisi untuk membantu pengusul',
                'improvement_suggestions.min' => 'Saran perbaikan minimal 20 karakter agar lebih konstruktif',
                'improvement_suggestions.max' => 'Saran perbaikan maksimal 2000 karakter',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            // Check authorization based on role and proposal status
            $canReject = $this->canRejectProposal($user, $proposal);
            
            if (!$canReject) {
                return response()->json([
                    'success' => false,
                    'message' => 'Anda tidak memiliki akses untuk menolak proposal ini pada status saat ini',
                    'debug' => [
                        'your_role' => $user->role,
                        'proposal_status' => $proposal->status
                    ]
                ], 403);
            }

            $proposal->update([
                'status' => Proposal::STATUS_REJECTED,
                'rejected_at' => now(),
                'rejected_by' => $user->id,
                'rejected_by_role' => $user->role,
                'rejection_reason' => $request->rejection_reason,
                'improvement_suggestions' => $request->improvement_suggestions,
            ]);

            // Load relations for response
            $proposal->load(['user', 'rkam', 'rejectedByUser']);

            // Log rejection action
            Log::info('Proposal rejected', [
                'proposal_id' => $proposal->id,
                'rejected_by' => $user->id,
                'rejected_by_role' => $user->role,
                'proposal_owner' => $proposal->user_id
            ]);

            // TODO: Send notification to proposer
            // TODO: Create approval workflow record

            return response()->json([
                'success' => true,
                'message' => 'Proposal berhasil ditolak dan feedback telah dikirimkan ke pengusul',
                'data' => $proposal
            ]);
        } catch (\Exception $e) {
            Log::error('Error rejecting proposal: ' . $e->getMessage(), [
                'proposal_id' => $id,
                'user_id' => $request->user()->id ?? null,
                'trace' => $e->getTraceAsString()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Failed to reject proposal',
                'error' => config('app.debug') ? $e->getMessage() : 'Internal server error'
            ], 500);
        }
    }

    /**
     * Check if user can reject proposal based on role and proposal status
     */
    private function canRejectProposal($user, $proposal): bool
    {
        // Verifikator can reject if status is submitted (pending_verifikator)
        if ($user->isVerifikator() && $proposal->status === Proposal::STATUS_SUBMITTED) {
            return true;
        }

        // Kepala Madrasah can reject if status is verified (pending_kepala)
        if ($user->isKepalaMadrasah() && $proposal->status === Proposal::STATUS_VERIFIED) {
            return true;
        }

        // Komite can reject if status is approved and requires committee
        if ($user->isKomiteMadrasah() 
            && $proposal->status === Proposal::STATUS_APPROVED 
            && $proposal->requires_committee_approval) {
            return true;
        }

        // Bendahara can reject if status is final_approved (pending_bendahara)
        if ($user->isBendahara() && $proposal->status === Proposal::STATUS_FINAL_APPROVED) {
            return true;
        }

        return false;
    }

    /**
     * Final approve proposal (Komite Madrasah role)
     * Only for proposals > 50M
     */
    public function finalApprove(Request $request, $id)
    {
        $proposal = Proposal::findOrFail($id);
        $user = $request->user();

        // Authorization: Only Komite Madrasah can final approve
        if (!$user->isKomite()) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized: Only Komite Madrasah can give final approval',
                'debug' => [
                    'your_role' => $user->role,
                    'required_role' => 'komite'
                ]
            ], 403);
        }

        // Status validation
        if ($proposal->status !== Proposal::STATUS_APPROVED) {
            return response()->json([
                'success' => false,
                'message' => "Cannot final approve: Proposal status is '{$proposal->status}'"
            ], 422);
        }

        // Check if committee approval is required
        if (!$proposal->requires_committee_approval) {
            return response()->json([
                'success' => false,
                'message' => 'This proposal does not require committee approval'
            ], 422);
        }

        $proposal->update([
            'status' => Proposal::STATUS_FINAL_APPROVED,
            'final_approved_at' => now(),
            'final_approved_by' => $user->id,
        ]);

        // TODO: Create approval workflow record

        return response()->json([
            'success' => true,
            'message' => 'Proposal final approved successfully',
            'data' => $proposal->fresh()->load([
                'user:id,full_name,email,role',
                'rkam:id,kategori,item_name,pagu,tahun_anggaran',
                'verifier:id,full_name,role',
                'approver:id,full_name,role',
                'finalApprover:id,full_name,role'
            ])
        ]);
    }
    
    /**
     * GET /api/proposals/my-proposals
     * Get all proposals for current user (Pengusul)
     */
    public function myProposals(Request $request)
    {
        try {
            $user = $request->user();
            
            // Get all proposals for current user
            $proposals = Proposal::where('user_id', $user->id)
                ->with([
                    'rkam:id,kategori,item_name,pagu,tahun_anggaran',
                    'user:id,full_name,email,role',
                    'verifier:id,full_name,role',
                    'approver:id,full_name,role',
                    'finalApprover:id,full_name,role',
                    'payment' => function($query) {
                        $query->select([
                            'id', 'proposal_id', 'amount', 'recipient_name', 
                            'payment_method', 'payment_proof_url', 'payment_proof_file',
                            'status', 'completed_at', 'processed_at', 'notes', 'admin_notes'
                        ]);
                    }
                ])
                ->orderBy('created_at', 'desc')
                ->get();
            
            // Load rejectedByUser for proposals that have been rejected
            $proposals->each(function($proposal) {
                if ($proposal->rejected_by) {
                    $proposal->load('rejectedByUser:id,full_name,role,email');
                }
            });
            
            return response()->json([
                'success' => true,
                'message' => 'Proposals retrieved successfully',
                'data' => $proposals,
                'count' => $proposals->count()
            ]);
        } catch (\Exception $e) {
            Log::error('Error fetching user proposals: ' . $e->getMessage(), [
                'user_id' => $request->user()->id ?? null,
                'trace' => $e->getTraceAsString()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve proposals',
                'error' => config('app.debug') ? $e->getMessage() : 'Internal server error'
            ], 500);
        }
    }
    
    /**
     * GET /api/proposals/statistics
     * Get proposal statistics for current user (Pengusul)
     */
    public function statistics(Request $request)
    {
        $user = $request->user();
        
        $stats = [
            'total' => Proposal::where('user_id', $user->id)->count(),
            'draft' => Proposal::where('user_id', $user->id)->where('status', Proposal::STATUS_DRAFT)->count(),
            'submitted' => Proposal::where('user_id', $user->id)->where('status', Proposal::STATUS_SUBMITTED)->count(),
            'verified' => Proposal::where('user_id', $user->id)->where('status', Proposal::STATUS_VERIFIED)->count(),
            'approved' => Proposal::where('user_id', $user->id)->where('status', Proposal::STATUS_APPROVED)->count(),
            'final_approved' => Proposal::where('user_id', $user->id)->where('status', Proposal::STATUS_FINAL_APPROVED)->count(),
            'rejected' => Proposal::where('user_id', $user->id)->where('status', Proposal::STATUS_REJECTED)->count(),
            'payment_processing' => Proposal::where('user_id', $user->id)->where('status', Proposal::STATUS_PAYMENT_PROCESSING)->count(),
            'completed' => Proposal::where('user_id', $user->id)->where('status', Proposal::STATUS_COMPLETED)->count(),
            'total_amount_completed' => Proposal::where('user_id', $user->id)
                ->where('status', Proposal::STATUS_COMPLETED)
                ->sum('jumlah_pengajuan')
        ];
        
        return response()->json([
            'success' => true,
            'message' => 'Statistics retrieved successfully',
            'data' => $stats
        ]);
    }

    /**
     * Get proposals by kategori
     */
    public function getByKategori($kategori)
    {
        $validKategori = ['Kurikulum', 'Kantor', 'Sarana Prasarana', 'Humas', 'Kesiswaan', 'Komite'];
        
        if (!in_array($kategori, $validKategori)) {
            return response()->json([
                'success' => false,
                'message' => 'Kategori tidak valid. Valid: ' . implode(', ', $validKategori)
            ], 400);
        }

        $proposals = Proposal::where('kategori', $kategori)
            ->with(['user', 'rkam'])
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json([
            'success' => true,
            'message' => 'Proposals retrieved successfully',
            'data' => $proposals
        ]);
    }
}