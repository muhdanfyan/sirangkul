<?php

namespace App\Http\Controllers;

use App\Models\Proposal;
use App\Models\ProposalAttachment;
use Illuminate\Http\Request;

class ProposalAttachmentController extends Controller
{
    public function store(Request $request, Proposal $proposal)
    {
        $file = $request->file('file');
        $path = $file->store('attachments');

        $attachment = $proposal->attachments()->create([
            'file_name' => $file->getClientOriginalName(),
            'file_path' => $path,
        ]);

        return response()->json($attachment);
    }

    public function destroy(ProposalAttachment $attachment)
    {
        $attachment->delete();

        return response()->json(['message' => 'Attachment deleted']);
    }
}
