<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreProposalRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'rkam_id' => 'required|exists:rkam,id',
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'jumlah_pengajuan' => 'required|numeric|min:1',
            'kategori' => 'required|in:Kurikulum,Kantor,Sarana Prasarana,Humas,Kesiswaan,Komite',
            'urgency' => 'nullable|in:Rendah,Normal,Tinggi,Mendesak',
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date|after_or_equal:start_date',
        ];
    }

    /**
     * Get custom messages for validator errors.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'kategori.in' => 'Kategori harus salah satu dari: Kurikulum, Kantor, Sarana Prasarana, Humas, Kesiswaan, atau Komite',
            'rkam_id.required' => 'RKAM wajib dipilih',
            'rkam_id.exists' => 'RKAM yang dipilih tidak valid',
            'title.required' => 'Judul proposal wajib diisi',
            'description.required' => 'Deskripsi proposal wajib diisi',
            'jumlah_pengajuan.required' => 'Jumlah pengajuan wajib diisi',
            'jumlah_pengajuan.min' => 'Jumlah pengajuan minimal Rp 1',
        ];
    }
}
