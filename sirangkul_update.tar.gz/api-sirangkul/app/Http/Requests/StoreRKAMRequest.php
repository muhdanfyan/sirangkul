<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreRKAMRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        // Only bendahara & admin can create RKAM
        $user = $this->user();
        
        if (!$user) {
            return false;
        }
        
        return in_array($user->role, ['bendahara', 'administrator']);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'item_name' => 'required|string|max:255',
            'kategori' => 'required|in:Kurikulum,Kantor,Sarana Prasarana,Humas,Kesiswaan,Komite',
            'pagu' => 'required|numeric|min:0',
            'volume' => 'nullable|string|max:100',
            'description' => 'nullable|string',
        ];
    }

    /**
     * Get custom messages for validator errors.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'kategori.in' => 'Kategori harus salah satu dari: Kurikulum, Kantor, Sarana Prasarana, Humas, Kesiswaan, atau Komite',
            'item_name.required' => 'Nama item RKAM wajib diisi',
            'pagu.required' => 'Pagu anggaran wajib diisi',
            'pagu.min' => 'Pagu anggaran tidak boleh negatif',
        ];
    }
}
