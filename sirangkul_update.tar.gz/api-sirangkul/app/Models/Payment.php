<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Payment extends Model
{
    use HasFactory;
    
    protected $keyType = 'string';
    public $incrementing = false;
    
    protected $fillable = [
        'proposal_id',
        'amount',
        'recipient_name',
        'recipient_account',
        'bank_name',
        'payment_method',
        'payment_reference',
        'payment_proof_url',
        'payment_proof_file',
        'status',
        'notes',
        'admin_notes',
        'rejection_reason',
        'improvement_suggestions',
        'rejected_at',
        'rejected_by',
        'rejected_by_role',
        'processed_at',
        'completed_at',
        'processed_by',
    ];
    
    protected $casts = [
        'amount' => 'decimal:2',
        'rejected_at' => 'datetime',
        'processed_at' => 'datetime',
        'completed_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
    
    // Status constants
    const STATUS_PENDING = 'pending';
    const STATUS_PROCESSING = 'processing';
    const STATUS_COMPLETED = 'completed';
    const STATUS_FAILED = 'failed';
    const STATUS_REJECTED = 'rejected';
    
    // Payment methods
    const METHOD_TRANSFER = 'transfer';
    const METHOD_CASH = 'cash';
    const METHOD_CHECK = 'check';
    
    protected static function boot()
    {
        parent::boot();
        
        static::creating(function ($model) {
            if (empty($model->id)) {
                $model->id = (string) Str::uuid();
            }
        });
    }
    
    /**
     * Relasi ke Proposal
     */
    public function proposal()
    {
        return $this->belongsTo(Proposal::class, 'proposal_id');
    }
    
    /**
     * Relasi ke User (Bendahara yang proses)
     */
    public function processedByUser()
    {
        return $this->belongsTo(User::class, 'processed_by');
    }
    
    /**
     * Relasi ke User yang melakukan rejection
     */
    public function rejectedByUser()
    {
        return $this->belongsTo(User::class, 'rejected_by');
    }
    
    /**
     * Check if payment can be processed
     */
    public function canBeProcessed()
    {
        return $this->status === self::STATUS_PENDING;
    }
    
    /**
     * Check if payment can be completed
     */
    public function canBeCompleted()
    {
        return $this->status === self::STATUS_PROCESSING;
    }
    
    /**
     * Get status badge color
     */
    public function getStatusBadgeAttribute()
    {
        return [
            'pending' => 'bg-yellow-100 text-yellow-800',
            'processing' => 'bg-blue-100 text-blue-800',
            'completed' => 'bg-green-100 text-green-800',
            'failed' => 'bg-red-100 text-red-800',
            'rejected' => 'bg-red-100 text-red-800',
        ][$this->status] ?? 'bg-gray-100 text-gray-800';
    }
    
    /**
     * Get status label
     */
    public function getStatusLabelAttribute()
    {
        return [
            'pending' => 'Menunggu',
            'processing' => 'Diproses',
            'completed' => 'Selesai',
            'failed' => 'Gagal',
            'rejected' => 'Ditolak',
        ][$this->status] ?? $this->status;
    }
}
