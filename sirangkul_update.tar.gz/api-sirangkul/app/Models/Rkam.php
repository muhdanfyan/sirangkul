<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class Rkam extends Model
{
    use HasFactory, HasUuids;

    protected $table = 'rkams';

    /**
     * Valid categories
     */
    public static $validKategori = [
        'Kurikulum',
        'Kantor',
        'Sarana Prasarana',
        'Humas',
        'Kesiswaan',
        'Komite',
    ];

    protected $fillable = [
        'parent_id',
        'category_id',
        'kategori',
        'item_name',
        'pagu',
        'volume',
        'satuan',
        'unit_price',
        'dana_bos',
        'dana_komite',
        'description',
        'tahun_anggaran',
        'deskripsi',
        'sort_order',
    ];

    /**
     * The "booted" method of the model.
     */
    protected static function booted(): void
    {
        static::addGlobalScope('order', function ($query) {
            $query->orderBy('sort_order', 'asc');
        });
    }

    protected $casts = [
        'pagu' => 'decimal:2',
        'unit_price' => 'decimal:2',
        'dana_bos' => 'decimal:2',
        'dana_komite' => 'decimal:2',
        'tahun_anggaran' => 'integer',
    ];

    /**
     * Relationship: RKAM belongs to a formal Category
     */
    public function category()
    {
        return $this->belongsTo(Category::class, 'category_id');
    }

    /**
     * Relationship: RKAM belongs to a Parent RKAM (Group)
     */
    public function parent()
    {
        return $this->belongsTo(Rkam::class, 'parent_id');
    }

    /**
     * Relationship: RKAM has many Children (Items)
     */
    public function children()
    {
        return $this->hasMany(Rkam::class, 'parent_id');
    }

    /**
     * Scope untuk filter by kategori
     */
    public function scopeKategori($query, $kategori)
    {
        return $query->where('kategori', $kategori);
    }

    /**
     * Scope untuk RKAM yang masih ada sisa
     */
    public function scopeAvailable($query)
    {
        return $query->whereRaw('pagu > (SELECT COALESCE(SUM(jumlah_pengajuan), 0) FROM proposals WHERE proposals.rkam_id = rkam.id AND proposals.status IN ("approved", "final_approved"))');
    }

    /**
     * Relationship: RKAM has many Proposals
     */
    public function proposals()
    {
        return $this->hasMany(Proposal::class, 'rkam_id');
    }

    /**
     * Computed attribute: Total terpakai (total dari proposals yang approved)
     */
    public function getTerpakaiAttribute(): float
    {
        return (float) $this->proposals()
                    ->where('status', 'approved')
                    ->sum('jumlah_pengajuan');
    }

    /**
     * Computed attribute: Sisa anggaran
     */
    public function getSisaAttribute(): float
    {
        return (float) $this->pagu - $this->terpakai;
    }

    /**
     * Computed attribute: Persentase penggunaan
     */
    public function getPersentaseAttribute(): float
    {
        if ($this->pagu <= 0) {
            return 0;
        }
        return ($this->terpakai / $this->pagu) * 100;
    }

    /**
     * Computed attribute: Status (Normal/Warning/Critical)
     */
    public function getStatusAttribute(): string
    {
        $persentase = $this->persentase;
        
        if ($persentase >= 90) {
            return 'Critical';
        } elseif ($persentase >= 75) {
            return 'Warning';
        }
        
        return 'Normal';
    }

    /**
     * Append computed attributes to JSON
     */
    protected $appends = ['terpakai', 'sisa', 'persentase', 'status'];
}
