<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class Category extends Model
{
    use HasFactory, HasUuids;

    protected $fillable = [
        'name',
        'description',
        'color',
        'sort_order',
    ];

    /**
     * Relationship: Category has many RKAM items
     */
    public function rkams()
    {
        return $this->hasMany(Rkam::class, 'category_id');
    }
}
