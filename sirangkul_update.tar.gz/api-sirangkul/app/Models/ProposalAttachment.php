<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class ProposalAttachment extends Model
{
    use HasFactory, HasUuids;

    public $timestamps = false;

    protected $fillable = [
        'proposal_id',
        'file_name',
        'file_path',
    ];

    public function proposal()
    {
        return $this->belongsTo(Proposal::class);
    }
}
