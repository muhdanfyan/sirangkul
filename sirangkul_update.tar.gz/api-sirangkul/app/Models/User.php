<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

use Illuminate\Support\Str; // Import Str facade

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    // Add these properties for UUID primary key
    public $incrementing = false;
    protected $keyType = 'string';

    /**
     * The "booting" method of the model.
     *
     * @return void
     */
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->{$model->getKeyName()} = Str::uuid();
        });
    }

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'full_name',
        'email',
        'password',
        'role',
        'is_active',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
        'created_at',
        'updated_at',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    // Role constants
    const ROLE_PENGUSUL = 'pengusul';
    const ROLE_VERIFIKATOR = 'verifikator';
    const ROLE_KEPALA_MADRASAH = 'kepala_madrasah';
    const ROLE_KOMITE = 'komite_madrasah';
    const ROLE_BENDAHARA = 'bendahara';
    const ROLE_ADMIN = 'admin';

    /**
     * Check if user has specific role (case-insensitive)
     */
    public function hasRole(string $role): bool
    {
        return strtolower(trim($this->role)) === strtolower(trim($role));
    }

    /**
     * Check if user has any of the specified roles
     */
    public function hasAnyRole(array $roles): bool
    {
        foreach ($roles as $role) {
            if ($this->hasRole($role)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Check if user is Verifikator
     */
    public function isVerifikator(): bool
    {
        return $this->hasRole(self::ROLE_VERIFIKATOR);
    }

    /**
     * Check if user is Kepala Madrasah
     */
    public function isKepalaMadrasah(): bool
    {
        return $this->hasRole(self::ROLE_KEPALA_MADRASAH);
    }

    /**
     * Check if user is Komite Madrasah
     */
    public function isKomite(): bool
    {
        return $this->hasRole(self::ROLE_KOMITE);
    }

    /**
     * Alias for isKomite() for consistency
     */
    public function isKomiteMadrasah(): bool
    {
        return $this->isKomite();
    }

    /**
     * Check if user is Bendahara
     */
    public function isBendahara(): bool
    {
        return $this->hasRole(self::ROLE_BENDAHARA);
    }

    /**
     * Check if user is Admin
     */
    public function isAdmin(): bool
    {
        return $this->hasRole(self::ROLE_ADMIN);
    }

    /**
     * Check if user is Pengusul
     */
    public function isPengusul(): bool
    {
        return $this->hasRole(self::ROLE_PENGUSUL);
    }

    public function proposals()
    {
        return $this->hasMany(Proposal::class);
    }

    public function feedback()
    {
        return $this->hasMany(Feedback::class);
    }

    public function notifications()
    {
        return $this->hasMany(Notification::class);
    }
}