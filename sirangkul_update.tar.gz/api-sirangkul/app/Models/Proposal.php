<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str; // Import Str facade

class Proposal extends Model
{
    use HasFactory;

    // Add these properties for UUID primary key
    public $incrementing = false;
    protected $keyType = 'string';

    /**
     * The "booting" method of the model.
     *
     * @return void
     */
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->{$model->getKeyName()} = Str::uuid();
            
            // Auto-set requires_committee_approval if not set
            if (is_null($model->requires_committee_approval)) {
                // Check if budget > 50 million
                $model->requires_committee_approval = 
                    floatval($model->jumlah_pengajuan) > 50000000;
            }
        });

        // Auto-set requires_committee_approval on updating jumlah_pengajuan
        static::updating(function ($model) {
            if ($model->isDirty('jumlah_pengajuan')) {
                $model->requires_committee_approval = 
                    floatval($model->jumlah_pengajuan) > 50000000;
            }
        });
    }

    // Status constants
    const STATUS_DRAFT = 'draft';
    const STATUS_SUBMITTED = 'submitted';
    const STATUS_VERIFIED = 'verified';
    const STATUS_APPROVED = 'approved';
    const STATUS_REJECTED = 'rejected';
    const STATUS_FINAL_APPROVED = 'final_approved';
    const STATUS_PAYMENT_PROCESSING = 'payment_processing';
    const STATUS_COMPLETED = 'completed';

    /**
     * Valid categories
     */
    public static $validKategori = [
        'Kurikulum',
        'Kantor',
        'Sarana Prasarana',
        'Humas',
        'Kesiswaan',
        'Komite',
    ];

    protected $fillable = [
        'user_id',
        'rkam_id',
        'title',
        'description',
        'jumlah_pengajuan',
        'kategori',
        'urgency',
        'start_date',
        'end_date',
        'status',
        'submitted_at',
        'verified_at',
        'verified_by',
        'approved_at',
        'approved_by',
        'rejected_at',
        'rejected_by',
        'rejected_by_role',
        'rejection_reason',
        'improvement_suggestions',
        'final_approved_at',
        'final_approved_by',
        'completed_at',
        'requires_committee_approval',
        'resubmission_count',
        'last_resubmitted_at',
    ];

    protected $casts = [
        'jumlah_pengajuan' => 'decimal:2',
        'submitted_at' => 'datetime',
        'verified_at' => 'datetime',
        'approved_at' => 'datetime',
        'rejected_at' => 'datetime',
        'final_approved_at' => 'datetime',
        'completed_at' => 'datetime',
        'last_resubmitted_at' => 'datetime',
        'requires_committee_approval' => 'boolean',
        'resubmission_count' => 'integer',
        'start_date' => 'date',
        'end_date' => 'date',
    ];

    /**
     * Scope untuk filter by kategori
     */
    public function scopeKategori($query, $kategori)
    {
        return $query->where('kategori', $kategori);
    }

    /**
     * Relationship: Proposal belongs to User (Pengusul)
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Relationship: Proposal belongs to RKAM
     */
    public function rkam()
    {
        return $this->belongsTo(Rkam::class, 'rkam_id');
    }

    /**
     * Relationship: User yang melakukan verifikasi
     */
    public function verifier()
    {
        return $this->belongsTo(User::class, 'verified_by');
    }

    /**
     * Relationship: User yang melakukan approval (Kepala Madrasah)
     */
    public function approver()
    {
        return $this->belongsTo(User::class, 'approved_by');
    }

    /**
     * Relationship: User yang melakukan rejection
     */
    public function rejector()
    {
        return $this->belongsTo(User::class, 'rejected_by');
    }

    /**
     * Relationship: User who rejected the proposal (alias for rejector)
     */
    public function rejectedByUser()
    {
        return $this->belongsTo(User::class, 'rejected_by');
    }

    /**
     * Relationship: User yang melakukan final approval (Komite)
     */
    public function finalApprover()
    {
        return $this->belongsTo(User::class, 'final_approved_by');
    }

    /**
     * Old relationship name kept for backward compatibility
     */
    public function rkamItems()
    {
        return $this->hasMany(Rkam::class);
    }

    public function attachments()
    {
        return $this->hasMany(ProposalAttachment::class);
    }

    /**
     * Relationship: Proposal has one Payment
     */
    public function payment()
    {
        return $this->hasOne(Payment::class, 'proposal_id');
    }

    public function payments()
    {
        return $this->hasMany(Payment::class);
    }

    public function feedback()
    {
        return $this->hasMany(Feedback::class);
    }

    public function approvals()
    {
        return $this->hasMany(ApprovalWorkflow::class);
    }

    /**
     * Check if proposal is rejected
     */
    public function isRejected(): bool
    {
        return $this->status === self::STATUS_REJECTED && !is_null($this->rejected_at);
    }

    /**
     * Check if proposal has improvement suggestions
     */
    public function hasImprovementSuggestions(): bool
    {
        return !empty($this->improvement_suggestions);
    }

    /**
     * Check if proposal can be edited
     */
    public function canBeEdited(): bool
    {
        return in_array($this->status, [self::STATUS_DRAFT, self::STATUS_REJECTED]);
    }

    /**
     * Check if proposal can be deleted
     */
    public function canBeDeleted(): bool
    {
        return $this->status === self::STATUS_DRAFT;
    }

    /**
     * Check if proposal can be submitted
     */
    public function canBeSubmitted(): bool
    {
        return $this->status === self::STATUS_DRAFT;
    }

    /**
     * Check if proposal needs payment
     */
    public function needsPayment(): bool
    {
        return $this->status === self::STATUS_FINAL_APPROVED;
    }

    /**
     * Check if proposal is being paid
     */
    public function isBeingPaid(): bool
    {
        return $this->status === self::STATUS_PAYMENT_PROCESSING;
    }

    /**
     * Get status badge color for frontend
     */
    public function getStatusBadgeAttribute(): string
    {
        return match($this->status) {
            self::STATUS_DRAFT => 'gray',
            self::STATUS_SUBMITTED => 'blue',
            self::STATUS_VERIFIED => 'cyan',
            self::STATUS_APPROVED => 'purple',
            self::STATUS_REJECTED => 'red',
            self::STATUS_FINAL_APPROVED => 'green',
            self::STATUS_PAYMENT_PROCESSING => 'yellow',
            self::STATUS_COMPLETED => 'emerald',
            default => 'gray',
        };
    }

    /**
     * Get human readable status
     */
    public function getStatusLabelAttribute(): string
    {
        return match($this->status) {
            self::STATUS_DRAFT => 'Draft',
            self::STATUS_SUBMITTED => 'Submitted',
            self::STATUS_VERIFIED => 'Verified',
            self::STATUS_APPROVED => 'Approved',
            self::STATUS_REJECTED => 'Rejected',
            self::STATUS_FINAL_APPROVED => 'Final Approved',
            self::STATUS_PAYMENT_PROCESSING => 'Payment Processing',
            self::STATUS_COMPLETED => 'Completed',
            default => 'Unknown',
        };
    }

    /**
     * Get next approver role
     */
    public function getNextApproverAttribute(): ?string
    {
        return match($this->status) {
            self::STATUS_SUBMITTED => 'Verifikator',
            self::STATUS_VERIFIED => 'Kepala Madrasah',
            self::STATUS_APPROVED => $this->requires_committee_approval ? 'Komite Madrasah' : null,
            self::STATUS_FINAL_APPROVED => 'Bendahara',
            default => null,
        };
    }

    /**
     * Append computed attributes
     */
    protected $appends = ['status_badge', 'status_label', 'next_approver'];
}