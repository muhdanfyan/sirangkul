<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Update existing rejected proposals without improvement_suggestions
        // Set default message for old rejections
        DB::table('proposals')
            ->where('status', 'rejected')
            ->whereNull('improvement_suggestions')
            ->update([
                'improvement_suggestions' => 'Harap perbaiki proposal sesuai dengan alasan penolakan di atas dan ajukan kembali.',
                'rejected_by_role' => DB::raw("
                    (SELECT role FROM users WHERE users.id = proposals.rejected_by)
                ")
            ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // No need to reverse - data migration
    }
};
