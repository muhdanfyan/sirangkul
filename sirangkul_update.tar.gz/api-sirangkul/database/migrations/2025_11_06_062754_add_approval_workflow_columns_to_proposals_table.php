<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('proposals', function (Blueprint $table) {
            // Timestamps untuk tracking workflow
            $table->timestamp('verified_at')->nullable()->after('submitted_at');
            $table->uuid('verified_by')->nullable()->after('verified_at');
            
            $table->uuid('approved_by')->nullable()->after('approved_at');
            
            $table->uuid('rejected_by')->nullable()->after('rejected_at');
            $table->text('rejection_reason')->nullable()->after('rejected_by');
            
            $table->timestamp('final_approved_at')->nullable()->after('rejection_reason');
            $table->uuid('final_approved_by')->nullable()->after('final_approved_at');
            
            $table->timestamp('completed_at')->nullable()->after('final_approved_by');
            
            // Flag untuk approval komite
            $table->boolean('requires_committee_approval')->default(false)->after('completed_at');
            
            // Foreign keys
            $table->foreign('verified_by')->references('id')->on('users')->onDelete('set null');
            $table->foreign('approved_by')->references('id')->on('users')->onDelete('set null');
            $table->foreign('rejected_by')->references('id')->on('users')->onDelete('set null');
            $table->foreign('final_approved_by')->references('id')->on('users')->onDelete('set null');
        });
        
        // Update status enum to include new statuses (MySQL only)
        if (DB::getDriverName() === 'mysql') {
            DB::statement("ALTER TABLE proposals MODIFY COLUMN status ENUM('draft', 'submitted', 'verified', 'approved', 'rejected', 'final_approved', 'payment_processing', 'completed') DEFAULT 'draft'");
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('proposals', function (Blueprint $table) {
            // Drop foreign keys first
            $table->dropForeign(['verified_by']);
            $table->dropForeign(['approved_by']);
            $table->dropForeign(['rejected_by']);
            $table->dropForeign(['final_approved_by']);
            
            // Drop columns
            $table->dropColumn([
                'verified_at',
                'verified_by',
                'approved_by',
                'rejected_by',
                'rejection_reason',
                'final_approved_at',
                'final_approved_by',
                'completed_at',
                'requires_committee_approval'
            ]);
        });
        
        // Revert status enum (MySQL only)
        if (DB::getDriverName() === 'mysql') {
            DB::statement("ALTER TABLE proposals MODIFY COLUMN status ENUM('draft', 'submitted', 'approved', 'rejected') DEFAULT 'draft'");
        }
    }
};
