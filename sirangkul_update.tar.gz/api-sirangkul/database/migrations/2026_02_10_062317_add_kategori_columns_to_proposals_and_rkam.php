<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Add columns to proposals table
        Schema::table('proposals', function (Blueprint $table) {
            $table->string('kategori')->nullable()->after('jumlah_pengajuan');
            $table->string('urgency')->nullable()->after('kategori');
            $table->date('start_date')->nullable()->after('urgency');
            $table->date('end_date')->nullable()->after('start_date');
        });

        // Add columns to rkam table
        Schema::table('rkam', function (Blueprint $table) {
            if (!Schema::hasColumn('rkam', 'volume')) {
                $table->string('volume')->nullable()->after('pagu');
            }
            if (!Schema::hasColumn('rkam', 'description')) {
                $table->text('description')->nullable()->after('volume');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('proposals', function (Blueprint $table) {
            $table->dropColumn(['kategori', 'urgency', 'start_date', 'end_date']);
        });

        Schema::table('rkam', function (Blueprint $table) {
            if (Schema::hasColumn('rkam', 'volume')) {
                $table->dropColumn('volume');
            }
            if (Schema::hasColumn('rkam', 'description')) {
                $table->dropColumn('description');
            }
        });
    }
};
