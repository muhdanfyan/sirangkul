<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('payments', function (Blueprint $table) {
            $table->text('rejection_reason')->nullable()->after('admin_notes');
            $table->text('improvement_suggestions')->nullable()->after('rejection_reason');
            $table->timestamp('rejected_at')->nullable()->after('improvement_suggestions');
            $table->uuid('rejected_by')->nullable()->after('rejected_at');
            $table->string('rejected_by_role', 50)->nullable()->after('rejected_by');
            
            // Foreign key
            $table->foreign('rejected_by')->references('id')->on('users')->onDelete('set null');
            
            // Indexes for performance
            $table->index('rejected_by');
            $table->index('rejected_at');
            $table->index('rejected_by_role');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('payments', function (Blueprint $table) {
            $table->dropForeign(['rejected_by']);
            $table->dropIndex(['rejected_by']);
            $table->dropIndex(['rejected_at']);
            $table->dropIndex(['rejected_by_role']);
            $table->dropColumn([
                'rejection_reason',
                'improvement_suggestions',
                'rejected_at',
                'rejected_by',
                'rejected_by_role'
            ]);
        });
    }
};
