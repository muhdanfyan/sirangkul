<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('proposals', function (Blueprint $table) {
            $table->text('improvement_suggestions')->nullable()->after('rejection_reason');
            $table->string('rejected_by_role', 50)->nullable()->after('rejected_by');
            
            // Add index for performance
            $table->index('rejected_by_role');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('proposals', function (Blueprint $table) {
            $table->dropIndex(['rejected_by_role']);
            $table->dropColumn(['improvement_suggestions', 'rejected_by_role']);
        });
    }
};
