<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('proposals', function (Blueprint $table) {
            $table->integer('resubmission_count')->default(0)->after('improvement_suggestions');
            $table->timestamp('last_resubmitted_at')->nullable()->after('resubmission_count');
            
            // Add index for tracking resubmissions
            $table->index('resubmission_count');
            $table->index('last_resubmitted_at');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('proposals', function (Blueprint $table) {
            $table->dropIndex(['resubmission_count']);
            $table->dropIndex(['last_resubmitted_at']);
            $table->dropColumn(['resubmission_count', 'last_resubmitted_at']);
        });
    }
};
