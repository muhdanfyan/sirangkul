<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Update existing RKAM categories to new format
        DB::table('rkam')->where('kategori', 'Renovasi')->update(['kategori' => 'Sarana Prasarana']);
        DB::table('rkam')->where('kategori', 'Pengadaan')->update(['kategori' => 'Sarana Prasarana']);
        DB::table('rkam')->where('kategori', 'Pelatihan')->update(['kategori' => 'Kurikulum']);
        DB::table('rkam')->where('kategori', 'Operasional')->update(['kategori' => 'Kantor']);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Rollback to old categories
        DB::table('rkam')->where('kategori', 'Sarana Prasarana')->update(['kategori' => 'Renovasi']);
        DB::table('rkam')->where('kategori', 'Kurikulum')->update(['kategori' => 'Pelatihan']);
        DB::table('rkam')->where('kategori', 'Kantor')->update(['kategori' => 'Operasional']);
    }
};
