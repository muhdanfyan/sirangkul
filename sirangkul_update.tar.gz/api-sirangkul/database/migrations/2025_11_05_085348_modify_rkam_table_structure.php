<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('rkam', function (Blueprint $table) {
            // Drop foreign key and old columns
            $table->dropForeign(['proposal_id']);
            $table->dropColumn(['proposal_id', 'quantity', 'unit_price', 'total_price']);
            
            // Add new columns
            $table->string('kategori')->after('id'); // Kategori: Renovasi, Pengadaan, Pelatihan, Operasional
            $table->decimal('pagu', 15, 2)->after('item_name'); // Budget total
            $table->integer('tahun_anggaran')->default(date('Y'))->after('pagu'); // Tahun anggaran
            $table->text('deskripsi')->nullable()->after('tahun_anggaran'); // Deskripsi detail
            $table->timestamp('updated_at')->nullable()->after('created_at'); // Add updated_at
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('rkam', function (Blueprint $table) {
            // Rollback
            $table->dropColumn(['kategori', 'pagu', 'tahun_anggaran', 'deskripsi', 'updated_at']);
            
            $table->uuid('proposal_id')->after('id');
            $table->integer('quantity')->after('item_name');
            $table->decimal('unit_price', 15, 2)->after('quantity');
            $table->decimal('total_price', 15, 2)->after('unit_price');
            
            $table->foreign('proposal_id')
                  ->references('id')
                  ->on('proposals')
                  ->onDelete('cascade');
        });
    }
};
