<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Check if kategori column exists before updating
        if (!Schema::hasColumn('proposals', 'kategori')) {
            // Column doesn't exist yet, skip this migration
            // It will be re-run after the column is added
            return;
        }

        // Update existing categories to new format
        // Mapping old categories to new ones
        DB::table('proposals')->where('kategori', 'Infrastruktur')->update(['kategori' => 'Sarana Prasarana']);
        DB::table('proposals')->where('kategori', 'Pendidikan')->update(['kategori' => 'Kurikulum']);
        DB::table('proposals')->where('kategori', 'Teknologi')->update(['kategori' => 'Sarana Prasarana']);
        DB::table('proposals')->where('kategori', 'Kesehatan')->update(['kategori' => 'Kesiswaan']);
        DB::table('proposals')->where('kategori', 'Kegiatan')->update(['kategori' => 'Kesiswaan']);
        DB::table('proposals')->where('kategori', 'Pemeliharaan')->update(['kategori' => 'Sarana Prasarana']);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Rollback to old categories (if needed)
        DB::table('proposals')->where('kategori', 'Sarana Prasarana')->update(['kategori' => 'Infrastruktur']);
        DB::table('proposals')->where('kategori', 'Kurikulum')->update(['kategori' => 'Pendidikan']);
        DB::table('proposals')->where('kategori', 'Kesiswaan')->update(['kategori' => 'Kegiatan']);
    }
};
