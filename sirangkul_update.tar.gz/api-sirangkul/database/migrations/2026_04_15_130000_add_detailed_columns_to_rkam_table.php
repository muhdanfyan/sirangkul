<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('rkam', function (Blueprint $table) {
            $table->string('satuan')->nullable()->after('volume');
            $table->decimal('unit_price', 15, 2)->default(0)->after('satuan');
            $table->decimal('dana_bos', 15, 2)->default(0)->after('unit_price');
            $table->decimal('dana_komite', 15, 2)->default(0)->after('dana_bos');
            $table->uuid('parent_id')->nullable()->after('id');
            
            $table->foreign('parent_id')
                  ->references('id')
                  ->on('rkam')
                  ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('rkam', function (Blueprint $table) {
            $table->dropForeign(['parent_id']);
            $table->dropColumn(['satuan', 'unit_price', 'dana_bos', 'dana_komite', 'parent_id']);
        });
    }
};
