<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('proposals', function (Blueprint $table) {
            $table->uuid('rkam_id')->nullable()->after('user_id');
            $table->decimal('jumlah_pengajuan', 15, 2)->default(0)->after('description');
            
            $table->foreign('rkam_id')
                  ->references('id')
                  ->on('rkam')
                  ->onDelete('restrict'); // Prevent deleting RKAM if there are proposals
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('proposals', function (Blueprint $table) {
            $table->dropForeign(['rkam_id']);
            $table->dropColumn(['rkam_id', 'jumlah_pengajuan']);
        });
    }
};
