<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('payments', function (Blueprint $table) {
            // Add new payment info columns
            $table->string('recipient_name', 255)->after('amount')->nullable();
            $table->string('recipient_account', 100)->after('recipient_name')->nullable();
            $table->string('bank_name', 100)->after('recipient_account')->nullable();
            
            // Add payment method columns
            $table->enum('payment_method', ['transfer', 'cash', 'check'])->after('bank_name')->default('transfer');
            $table->string('payment_reference', 100)->after('payment_method')->nullable();
            
            // Add proof column
            $table->string('payment_proof_url', 500)->after('payment_reference')->nullable();
            
            // Add notes columns
            $table->text('notes')->after('status')->nullable();
            $table->text('admin_notes')->after('notes')->nullable();
            
            // Add timestamp columns
            $table->timestamp('processed_at')->after('admin_notes')->nullable();
            $table->timestamp('completed_at')->after('processed_at')->nullable();
            $table->uuid('processed_by')->after('completed_at')->nullable();
            
            // Add updated_at timestamp
            $table->timestamp('updated_at')->after('created_at')->nullable();
            
            // Add foreign key for processed_by
            $table->foreign('processed_by')->references('id')->on('users');
            
            // Add indexes
            $table->index('status');
        });
        
        // Modify status enum to include new values (MySQL only)
        if (DB::getDriverName() === 'mysql') {
            DB::statement("ALTER TABLE payments MODIFY COLUMN status ENUM('pending', 'processing', 'completed', 'failed', 'paid') NOT NULL DEFAULT 'pending'");
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('payments', function (Blueprint $table) {
            // Drop foreign key and indexes
            $table->dropForeign(['processed_by']);
            $table->dropIndex(['status']);
            
            // Drop new columns
            $table->dropColumn([
                'recipient_name',
                'recipient_account',
                'bank_name',
                'payment_method',
                'payment_reference',
                'payment_proof_url',
                'notes',
                'admin_notes',
                'processed_at',
                'completed_at',
                'processed_by',
                'updated_at'
            ]);
        });
        
        // Revert status enum to original values (MySQL only)
        if (DB::getDriverName() === 'mysql') {
            DB::statement("ALTER TABLE payments MODIFY COLUMN status ENUM('pending', 'paid', 'failed') NOT NULL");
        }
    }
};
